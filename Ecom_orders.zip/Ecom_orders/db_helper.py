from pymongo import MongoClient
from bson import ObjectId
import os
 
 
class DBHelper:
    collection = None
 
    @classmethod
    def configure_mongo(cls):
        host = os.getenv('MONGO_HOST')
        port = os.getenv('MONGO_PORT')
        database_name = os.getenv('MONGO_DB_NAME')
        collection_name = os.getenv('MONGO_COLLECTION_NAME')
        #print(host)
        #print(port)
        client = MongoClient(host=host, port=int(port))
        db = client[database_name]
        cls.collection = db[collection_name]
 
    @classmethod
    def get_all_orders(cls):
        orders = cls.collection.find({})
        return list(orders)
   
    @classmethod
    def get_order_by_id(cls, id):
        return cls.collection.find_one({'_id':ObjectId(id)})
   
    @classmethod
    def add_order(cls, order):
        return cls.collection.insert_one({'_id':ObjectId(id)})
   
    @classmethod
    def update_order(cls, id, update_data):
        # Assuming `update_data` is a dictionary containing the fields to update
        result = cls.collection.update_one({'_id': ObjectId(id)}, {'$set': update_data})
        return result.modified_count > 0
       
    @classmethod
    def delete_order(cls, id):
        result = cls.collection.delete_one({'_id': ObjectId(id)})
        return result.deleted_count > 0