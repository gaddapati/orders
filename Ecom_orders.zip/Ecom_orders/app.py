from flask import Flask, jsonify, make_response
from dotenv import load_dotenv
import os
#from routes.products_api import get_blueprint as products_blueprint
from routes.orders_api import get_blueprint as users_blueprint
from db_helper import DBHelper
from flask_cors import CORS

load_dotenv()
DBHelper.configure_mongo()

app = Flask(__name__)
CORS(app)

# Middleware: Execute the method before each request
@app.before_request
def before():
    print("Hi, I am from before_request()")

# Error Handler
@app.errorhandler(404)
def page_not_found(e):
    return make_response(jsonify({'message': '404 Not Found'}), 404)

# Register Blueprints
#app.register_blueprint(products_blueprint())
app.register_blueprint(users_blueprint())

port = os.getenv('FLASK_PORT')

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=port)
