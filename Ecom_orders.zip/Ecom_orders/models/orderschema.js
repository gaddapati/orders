const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({

    order_id : Number,
    user_id : Number,
    quantity : Number,
    status : String,
});

const Order = mongoose.model('Order', orderSchema);
module.exports = Order; // default export
