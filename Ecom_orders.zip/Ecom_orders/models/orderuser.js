const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    order_id: {
        type: Number,
        required: true
    },
    user_id: {
        type: Number,
        required: true,
        unique: true
    },
    quantity: {
        type: Number,
        required: true
    },
    status: {
        type: String,
        required: true
    },
});

const User = mongoose.model('User', userSchema);
module.exports = User; //default export