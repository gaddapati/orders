from flask import Blueprint, jsonify, make_response
from flask import request
from db_helper import DBHelper
 
 
bp = Blueprint('orders_api', __name__)
 
def get_blueprint():
    return bp
 
# GET ALL THE orders
 
@bp.route('/api/orders', methods=['GET'])
def get_orders():
    data = DBHelper.get_all_orders()
    orders = []
    for doc in data :
        doc['_id'] = str(doc['_id'])
        orders.append(doc)
    return make_response(jsonify(orders), 200)
 
# GET THE PRODUCT DETAILS WITH THE order ID
 
@bp.route('/api/orders/<id>', methods=['GET'])
def get_order(id):
    order = DBHelper.get_product_by_id(id)
    if order:
        order['_id'] = str(order['_id'])
        return make_response(jsonify(order), 200)
    else:
        return make_response(jsonify({'message' : f'order  with id {id}'}), 200)
 
# ADD THE NEW order
 
@bp.route('/api/orders', methods=['POST'])
def add_order():
    order = request.get_json()
    result = DBHelper.add_order(order)
    return make_response(jsonify,({'message' : f' Add order {order}'}), 200)
 
# UPDATE THE order DETAILS WITH THE order ID
 
@bp.route('/api/orders/<id>', methods=['PUT'])
def update_order(id):
    order_data = request.get_json()
    if not order_data:
        return make_response(jsonify({'message': 'No data provided'}), 400)
   
    updated = DBHelper.update_order(id, order_data)
    if updated:
        return make_response(jsonify({'message': f'order with id {id} has been updated'}), 200)
    else:
        return make_response(jsonify({'message': f'order with id {id} not found'}), 404)
 
# DELETE THE order  WITH THE PRODUCT ID
 
@bp.route('/api/orders/<id>', methods=['DELETE'])
def delete_order(id):
    deleted = DBHelper.delete_order(id)
    if deleted:
        return make_response(jsonify({'message': f'order with id {id} has been deleted'}), 200)
    else:
        return make_response(jsonify({'message': f'order with id {id} not found'}), 404)