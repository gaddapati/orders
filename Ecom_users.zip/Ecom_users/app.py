# app.py

from flask import Flask
from routes.users_api import get_blueprint
from models import db

def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///your_database.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.register_blueprint(get_blueprint())
    db.init_app(app)
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
