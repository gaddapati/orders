from flask import Blueprint, jsonify, make_response
from flask import request
from db_helper import DBHelper


bp = Blueprint('products_api', __name__)

def get_blueprint():
    return bp

# GET ALL THE PRODUCTS

@bp.route('/api/products', methods=['GET'])
def get_products():
    data = DBHelper.get_all_products()
    products = []
    for doc in data :
        doc['_id'] = str(doc['_id'])
        products.append(doc)
    return make_response(jsonify(products), 200)

# GET THE PRODUCT DETAILS WITH THE PRODUCT ID

@bp.route('/api/products/<id>', methods=['GET'])
def get_product(id):
    product = DBHelper.get_product_by_id(id)
    if product:
        product['_id'] = str(product['_id'])
        return make_response(jsonify(product), 200)
    else:
        return make_response(jsonify({'message' : f'Product with id {id}'}), 200)

# ADD THE NEW PRODUCT
  
@bp.route('/api/products', methods=['POST'])
def add_product():
    product = request.get_json()
    result = DBHelper.add_product(product)
    return make_response(jsonify,({'message' : f' Add Product {product}'}), 200)

# UPDATE THE PRODUCT DETAILS WITH THE PRODUCT ID

@bp.route('/api/products/<id>', methods=['PUT'])
def update_product(id):
    product_data = request.get_json()
    if not product_data:
        return make_response(jsonify({'message': 'No data provided'}), 400)
    
    updated = DBHelper.update_product(id, product_data)
    if updated:
        return make_response(jsonify({'message': f'Product with id {id} has been updated'}), 200)
    else:
        return make_response(jsonify({'message': f'Product with id {id} not found'}), 404)

# DELETE THE PRODUCT WITH THE PRODUCT ID

@bp.route('/api/products/<id>', methods=['DELETE'])
def delete_product(id):
    deleted = DBHelper.delete_product(id)
    if deleted:
        return make_response(jsonify({'message': f'Product with id {id} has been deleted'}), 200)
    else:
        return make_response(jsonify({'message': f'Product with id {id} not found'}), 404)



